package com.testandroid.espressotesting

class Random {
    var name: String = ""

    constructor(name: String) {
        this.name = name
    }
}