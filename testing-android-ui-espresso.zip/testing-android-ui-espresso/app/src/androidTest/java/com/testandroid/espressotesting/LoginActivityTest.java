package com.testandroid.espressotesting;

import android.support.test.espresso.Espresso;
import android.support.test.espresso.action.ViewActions;
import android.support.test.rule.ActivityTestRule;

import org.junit.Rule;
import org.junit.Test;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

public class LoginActivityTest {

    @Rule
    public ActivityTestRule<com.testandroid.espressotesting.LoginActivity> LoginActivity;

    {
        LoginActivity = new ActivityTestRule<>(com.testandroid.espressotesting.LoginActivity.class);
    }
    private String username = "Shyam";
    private String password = "password";

    @Test
    public void  clickLoginButton_opensLoginUi() {
        onView(withId(R.id.et_username)).perform(ViewActions.typeText(username));
        onView(withId(R.id.et_password)).perform(ViewActions.typeText(password));
        onView(withId(R.id.btn_submit)).perform(ViewActions.scrollTo(), ViewActions.click());
        Espresso.onView(withId(R.id.tv_login)).check(matches(withText("Success")));
    }
}
